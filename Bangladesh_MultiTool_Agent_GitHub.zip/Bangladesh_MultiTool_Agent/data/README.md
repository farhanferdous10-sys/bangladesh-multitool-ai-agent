The app generates institutions.db, hospitals.db and restaurants.db here on first run.
Databases are excluded from Git because the original Hugging Face datasets are downloaded automatically.
Use their source pages for attribution and licensing; the institutional dataset has an unspecified license.
