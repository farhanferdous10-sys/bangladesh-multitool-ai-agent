"""Offline database tests; no Hugging Face download or Google API key needed."""
import sqlite3
import tempfile
import unittest
from pathlib import Path

import pandas as pd
from src.bd_agent import clean_columns, read_only_sql, save_table, table_schema


class TestDatabaseSafety(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.folder = Path(self.temp.name)
        save_table(pd.DataFrame({"Name": ["Hospital A", "Clinic B"], "District": ["Dhaka", "Khulna"], "Beds": [20, 10], "Score": [4.5, 3.7]}), "hospitals", self.folder)

    def tearDown(self):
        self.temp.cleanup()

    def test_schema_and_types(self):
        self.assertEqual(table_schema("hospitals", self.folder), {"name":"TEXT", "district":"TEXT", "beds":"INTEGER", "score":"REAL"})

    def test_count_and_limit(self):
        columns, rows = read_only_sql("hospitals", "SELECT COUNT(*) AS total FROM hospitals WHERE district = 'Dhaka'", self.folder)
        self.assertEqual((columns, rows), (["total"], [(1,)]))
        self.assertEqual(len(read_only_sql("hospitals", "SELECT * FROM hospitals", self.folder, max_rows=1)[1]), 1)

    def test_no_write_sql(self):
        for sql in ["DROP TABLE hospitals", "PRAGMA table_info(hospitals)", "DELETE FROM hospitals", "SELECT * FROM sqlite_master", "SELECT * FROM hospitals; DROP TABLE hospitals"]:
            with self.subTest(sql=sql), self.assertRaises((ValueError, sqlite3.DatabaseError)):
                read_only_sql("hospitals", sql, self.folder)

    def test_clean_duplicate_columns(self):
        df = pd.DataFrame([["A", "B"]], columns=["School Name", "School Name"])
        self.assertEqual(clean_columns(df).columns.tolist(), ["school_name", "school_name_2"])


if __name__ == "__main__":
    unittest.main()
